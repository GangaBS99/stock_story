"""Test script for document knowledge base"""
from document_knowledge_base import kb
from kb_chatbot_integration import handle_knowledge_query

# Test 1: Check loaded companies
print("Companies in knowledge base:")
companies = kb.get_all_companies()
for company in companies:
    docs = kb.get_company_documents(company)
    print(f"  - {company}: {len(docs)} documents")

print("\n" + "="*50 + "\n")

# Test 2: Sample queries
test_queries = [
    "What is the revenue of Press Release?",
    "Tell me about INR",
    "What products does Apple have?",
    "Microsoft Azure information"
]

for query in test_queries:
    print(f"Query: {query}")
    response = handle_knowledge_query(query)
    if response:
        print(f"Answer: {response['answer'][:200]}...")
        print(f"Confidence: {response['confidence']}")
        print(f"Sources: {len(response['sources'])} documents")
    else:
        print("No answer found")
    print()
