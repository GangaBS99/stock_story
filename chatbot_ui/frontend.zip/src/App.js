import logo from './logo.svg';
import './App.css';
import Chatbot from './chatbot';

function App() {
  return (
    <div className="App">
      <Chatbot/>
    </div>
  );
}

export default App;
