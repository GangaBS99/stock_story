import sys
sys.stdout.reconfigure(encoding='utf-8')

from document_knowledge_base import kb

print("=== Knowledge Base Status ===")
companies = kb.get_all_companies()
print(f"Total companies: {len(companies)}")
for company in companies:
    docs = kb.get_company_documents(company)
    print(f"  {company}: {len(docs)} documents")
print("\nKnowledge base is ready!")
